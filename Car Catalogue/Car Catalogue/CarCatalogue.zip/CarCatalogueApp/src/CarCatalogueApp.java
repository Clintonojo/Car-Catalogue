/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author Clinton
 */
public class CarCatalogueApp {
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            new CarCatalogueGUI().setVisible(true);
        });
    }
}
