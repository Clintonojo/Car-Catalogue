/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Clinton
 */
import java.io.*;
import java.util.ArrayList;

public class CarCatalogueManager implements Serializable {
    private ArrayList<CarItem> carItems;

    public CarCatalogueManager() {
        carItems = new ArrayList<>();
    }

    public void addCarItem(CarItem item) {
        carItems.add(item);
    }

    public void viewAllCarItems() {
        for (CarItem item : carItems) {
            System.out.println(item);
        }
    }

    public CarItem searchCarItemById(int id) {
        for (CarItem item : carItems) {
            if (item.getId() == id) {
                return item;
            }
        }
        return null;
    }

    public void deleteLastCarItem() {
        if (!carItems.isEmpty()) {
            int lastIndex = carItems.size() - 1;
            carItems.remove(lastIndex);
        }
    }

 public boolean saveCarItemsToStream(OutputStream outputStream) {
        try (ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream)) {
            objectOutputStream.writeObject(carItems);
            System.out.println("Car items saved to stream.");
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

  public static CarCatalogueManager loadCarCatalogueFromFile(String filePath) throws IOException, ClassNotFoundException {
        try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(filePath))) {
            CarCatalogueManager carCatalogueManager = new CarCatalogueManager();
            carCatalogueManager.carItems = (ArrayList<CarItem>) inputStream.readObject();
            System.out.println("Car items loaded from file.");
            return carCatalogueManager;
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            throw e;
        }
    }
    

    public void loadCarItemsFromFile(String filePath) throws IOException, ClassNotFoundException {
        try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(filePath))) {
            carItems = (ArrayList<CarItem>) inputStream.readObject();
            System.out.println("Car items loaded from file.");
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            throw e; // Re-throw the exception to handle it in the calling code
        }
    }

    public ArrayList<CarItem> getCarItems() {
        return carItems;
    }
}
