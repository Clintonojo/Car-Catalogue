/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Clinton
 */

//data 
import java.io.Serializable;

public class CarItem implements Serializable {
    private int id;
    private String make;
    private String registration;
    private double price;
    private int mileage;
    private double vrt;

    public CarItem(String make, String registration, double price, double vrt, int mileage, int id) {
        this.id = id;
        this.make = make;
        this.registration = registration;
        this.price = price;
        this.vrt = vrt;
        this.mileage = mileage;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getRegistration() {
        return registration;
    }

    public void setRegistration(String registration) {
        this.registration = registration;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getVrt() {
        return vrt;
    }

    public void setVrt(double vrt) {
        this.vrt = vrt;
    }

    public int getMileage() {
        return mileage;
    }

    public void setMileage(int mileage) {
        this.mileage = mileage;
    }

    @Override
    public String toString() {
        return "CarItem{" +
                "id=" + id +
                ", make='" + make + '\'' +
                ", registration='" + registration + '\'' +
                ", price=" + price +
                ", vrt=" + vrt +
                ", mileage=" + mileage +
                '}';
    }
}
